#include "List.h"

// ----------------
// Function headers
// ----------------


// converts 5 letter key into an integer
int convert(char key[5]); 

// returns the hash index of the key
int hash(char key[5], int slots);
